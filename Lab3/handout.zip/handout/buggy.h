#include <stdio.h>
#include <stdlib.h>


void init(int*, int, int*);
void add(int*, int, int);
void print_array(int* , int);
int contains(int*, int, int);

